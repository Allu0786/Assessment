<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\DB;

class BalanceController extends Controller
{
    public function show($id)
    {
        $user = User::findOrFail($id);

        $balance = $user->ledger()
            ->selectRaw("
                COALESCE(
                    SUM(
                        CASE
                            WHEN type = 'earn' THEN points
                            ELSE -points
                        END
                    ), 0
                ) AS balance
            ")
            ->value('balance');

        return response()->json([
            'user_id' => $user->id,
            'balance' => (int) $balance
        ]);
    }
}