<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function redemptions(Request $request)
    {
        $filters = $request->validate([
            'from' => ['required', 'date'],
            'to' => ['required', 'date', 'after_or_equal:from'],
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
        ]);

        $from = $filters['from'] . ' 00:00:00';
        $to = $filters['to'] . ' 23:59:59';

        $query = DB::table('redemptions as r')
            ->join('products as p', 'p.id', '=', 'r.product_id')
            ->join('categories as c', 'c.id', '=', 'p.category_id')
            ->join('users as u', 'u.id', '=', 'r.user_id')
            ->whereBetween('r.created_at', [$from, $to]);

        if (!empty($filters['category_id'])) {
            $query->where('p.category_id', $filters['category_id']);
        }

        $list = (clone $query)
            ->select(
                'r.id',
                'u.name as user_name',
                'p.name as product_name',
                'c.name as category_name',
                'r.points_spent',
                'r.created_at'
            )
            ->orderByDesc('r.created_at')
            ->get();

        // One SQL query for both totals
        $totals = DB::selectOne(
            "
            SELECT
                COUNT(*) AS total_count,
                COALESCE(SUM(r.points_spent), 0) AS total_points
            FROM redemptions r
            INNER JOIN products p
                ON p.id = r.product_id
            WHERE r.created_at >= ?
              AND r.created_at <= ?
              AND (? IS NULL OR p.category_id = ?)
            ",
            [
                $from,
                $to,
                $filters['category_id'] ?? null,
                $filters['category_id'] ?? null
            ]
        );

        return response()->json([
            'success' => true,
            'data' => $list,
            'total_count' => (int) $totals->total_count,
            'total_points' => (int) $totals->total_points
        ]);
    }
}