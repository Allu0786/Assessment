<?php

namespace App\Http\Controllers;

use App\Http\Requests\RedemptionRequest;
use App\Services\RedemptionService;

class RedemptionController extends Controller
{
    public function store(
        RedemptionRequest $request,
        RedemptionService $service
    ) {
        $result = $service->redeem(
            $request->user_id,
            $request->product_id
        );

        return response()->json([
            'success' => true,
            'message' => 'Product redeemed successfully',
            'data' => $result
        ], 201);
    }
}