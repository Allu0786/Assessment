<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RedemptionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'user_id' => [
                'required',
                'integer',
                'exists:users,id'
            ],

            'product_id' => [
                'required',
                'integer',
                'exists:products,id'
            ],
        ];
    }
}