<?php

namespace App\Services;

use App\Models\User;
use App\Models\Product;
use App\Models\Redemption;
use App\Models\PointsLedger;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class RedemptionService
{
    public function redeem(int $userId, int $productId)
    {
        return DB::transaction(function () use ($userId, $productId) {

            // 1. Lock user row
            $user = User::where('id', $userId)
                ->lockForUpdate()
                ->firstOrFail();

            // 2. Check profile
            $profile = $user->profile;

            if (!$profile || $profile->status === 'restricted') {
                throw ValidationException::withMessages([
                    'user_id' => 'Restricted users cannot redeem products.'
                ]);
            }

            // 3. Get product
            $product = Product::with('category.limit')
                ->where('is_active', true)
                ->find($productId);

            if (!$product) {
                throw ValidationException::withMessages([
                    'product_id' => 'Product is unavailable.'
                ]);
            }

            // 4. Calculate current balance
            $balance = PointsLedger::where('user_id', $userId)
                ->selectRaw("
                    COALESCE(
                        SUM(
                            CASE
                                WHEN type = 'earn' THEN points
                                ELSE -points
                            END
                        ), 0
                    ) AS balance
                ")
                ->value('balance');

            $balance = (int) $balance;

            // 5. Check sufficient points
            if ($balance < $product->points) {
                throw ValidationException::withMessages([
                    'points' => "Insufficient points. Required: {$product->points}, Available: {$balance}."
                ]);
            }

            // 6. Check category monthly limit
            $limit = $product->category->limit;

            if (!$limit) {
                throw ValidationException::withMessages([
                    'category' => 'Monthly limit is not configured.'
                ]);
            }

            $startOfMonth = now()->startOfMonth();
            $endOfMonth = now()->startOfMonth()->addMonth();

            $redeemedCount = Redemption::where('user_id', $userId)
                ->whereHas('product', function ($query) use ($product) {
                    $query->where('category_id', $product->category_id);
                })
                ->where('created_at', '>=', $startOfMonth)
                ->where('created_at', '<', $endOfMonth)
                ->count();

            if ($redeemedCount >= $limit->monthly_limit) {
                throw ValidationException::withMessages([
                    'category' => 'Monthly redemption limit reached for this category.'
                ]);
            }

            // 7. Create redemption
            $redemption = Redemption::create([
                'user_id' => $userId,
                'product_id' => $product->id,
                'points_spent' => $product->points
            ]);

            // 8. Create spending ledger entry
            PointsLedger::create([
                'user_id' => $userId,
                'product_id' => $product->id,
                'redemption_id' => $redemption->id,
                'type' => 'spend',
                'points' => $product->points
            ]);

            // 9. Return updated balance
            $remainingBalance = $balance - $product->points;

            return [
                'redemption' => $redemption,
                'points_spent' => $product->points,
                'remaining_balance' => $remainingBalance
            ];
        });
    }
}