<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('points_ledgers', function (Blueprint $table) {
              $table->id();

        $table->foreignId('user_id')
              ->constrained('users')
              ->cascadeOnDelete();

        $table->foreignId('product_id')
              ->nullable()
              ->constrained('products')
              ->nullOnDelete();

        $table->foreignId('redemption_id')
              ->nullable()
              ->constrained('redemptions')
              ->nullOnDelete();

        $table->enum('type', ['earn', 'spend']);

        $table->unsignedInteger('points');

        $table->timestamps();

        $table->index(['user_id', 'type']);
        $table->index(['type', 'created_at', 'user_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('points_ledgers');
    }
};
