<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Profile;
use App\Models\Category;
use App\Models\Product;
use App\Models\CategoryLimit;
use App\Models\PointsLedger;
use App\Models\Redemption;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class RewardsSeeder extends Seeder
{
    public function run(): void
    {
        DB::transaction(function () {

            // 1. Categories
            $categoryNames = [
                'Electronics',
                'Accessories',
                'Home Appliances',
                'Fashion',
                'Gift Cards'
            ];

            $categories = [];

            foreach ($categoryNames as $name) {
                $categories[] = Category::create([
                    'name' => $name
                ]);
            }

            // 2. Category limits
            foreach ($categories as $category) {
                CategoryLimit::create([
                    'category_id' => $category->id,
                    'monthly_limit' => 2
                ]);
            }

            // 3. Create 20 products
            $products = [];

            foreach ($categories as $category) {
                for ($i = 1; $i <= 4; $i++) {
                    $products[] = Product::create([
                        'category_id' => $category->id,
                        'name' => $category->name . ' Product ' . $i,
                        'points' => rand(100, 1000),
                        'is_active' => true
                    ]);
                }
            }

            // 4. Create 1000 users and starting points
            $users = [];

            for ($i = 1; $i <= 1000; $i++) {
                $user = User::create([
                    'name' => "User $i",
                    'email' => "user$i@example.com",
                    'password' => Hash::make('password123')
                ]);

                Profile::create([
                    'user_id' => $user->id,
                    'status' => $i % 10 === 0
                        ? 'restricted'
                        : 'active'
                ]);

                PointsLedger::create([
                    'user_id' => $user->id,
                    'type' => 'earn',
                    'points' => 10000
                ]);

                $users[] = $user->id;
            }

            // 5. Create 10000 past redemptions
            // Spread them across the previous 12 months.
            for ($i = 0; $i < 10000; $i++) {

                $userId = $users[array_rand($users)];

                $product = $products[array_rand($products)];

                // Keep seeded history within the monthly limit.
                // Each user can have at most 2 redemptions
                // per category per calendar month.
                $date = now()->subMonths(rand(1, 12))
                    ->subDays(rand(0, 27));

                $monthStart = $date->copy()->startOfMonth();
                $monthEnd = $date->copy()->addMonth()->startOfMonth();

                $existing = Redemption::where('user_id', $userId)
                    ->whereHas('product', function ($query) use ($product) {
                        $query->where(
                            'category_id',
                            $product->category_id
                        );
                    })
                    ->where('created_at', '>=', $monthStart)
                    ->where('created_at', '<', $monthEnd)
                    ->count();

                if ($existing >= 2) {
                    continue;
                }

                $redemption = Redemption::create([
                    'user_id' => $userId,
                    'product_id' => $product->id,
                    'points_spent' => $product->points,
                    'created_at' => $date,
                    'updated_at' => $date
                ]);

                PointsLedger::create([
                    'user_id' => $userId,
                    'product_id' => $product->id,
                    'redemption_id' => $redemption->id,
                    'type' => 'spend',
                    'points' => $product->points,
                    'created_at' => $date,
                    'updated_at' => $date
                ]);
            }
        });
    }
}