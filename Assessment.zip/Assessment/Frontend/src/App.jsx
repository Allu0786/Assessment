
import { useState } from "react";

function RewardsPage() {
  const [balance, setBalance] = useState(1000);
  const [message, setMessage] = useState("");

  const products = [
    { id: 1, name: "Headphones", points: 500 },
    { id: 2, name: "Smart Watch", points: 800 },
    { id: 3, name: "Bluetooth Speaker", points: 300 },
  ];

  const handleRedeem = (product) => {
    if (balance < product.points) {
      setMessage("Insufficient points!");
      return;
    }

    setBalance(balance - product.points);
    setMessage(`${product.name} redeemed successfully!`);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-5xl mx-auto">

        <h1 className="text-3xl font-bold mb-6">
          Rewards Store
        </h1>

        {/* Points Balance */}
        <div className="bg-blue-600 text-white p-6 rounded-xl mb-8">
          <p className="text-lg">Available Points</p>
          <h2 className="text-4xl font-bold">
            {balance}
          </h2>
        </div>

        {message && (
          <p className="mb-5 text-green-600 font-semibold">
            {message}
          </p>
        )}

        {/* Products */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">

          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white p-6 rounded-xl shadow"
            >
              <h2 className="text-xl font-bold mb-3">
                {product.name}
              </h2>

              <p className="text-gray-600 mb-5">
                Required Points: {product.points}
              </p>

              <button
                onClick={() => handleRedeem(product)}
                className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
              >
                Redeem
              </button>
            </div>
          ))}

        </div>
      </div>
    </div>
  );
}

export default RewardsPage;
