import axios from "axios";

// One client for the whole app. Change the URL here once, it changes everywhere.
const api = axios.create({
  baseURL: "http://127.0.0.1:8000/api",
  headers: { Accept: "application/json" },
});

export default api;
